- open-flash-chart.swf

  Open Flash Chart V2 - http://teethgrinder.co.uk/open-flash-chart-2/
  *
  * (C) 2007 John Glazebrook and is released under the LGPL License:
  * http://www.gnu.org/copyleft/lesser.html

  Patched version 2 Ichor by DZ from http://www.ofc2dz.com/